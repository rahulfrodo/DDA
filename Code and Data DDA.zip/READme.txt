###################INCLUDES#############################
1. DDA.html showing code and illustration of the methods.

2. DDA.Rmd file for the same.

3. Associated data files
   a) spearman correlations-20180913.RData: Gait             features/AD
   b) cogscores.RData: Cognitive scores information.
   c) prenormlmomallfeat.RData: Extracted L-moments
      for all gait features, prenormailized and scaled
      for JIVE.

