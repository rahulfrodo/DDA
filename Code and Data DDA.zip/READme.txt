###################INCLUDES#############################
1. DDA.html shows code and illustration of the proposed methods in Ghosal et al., 2021.

2. DDA.Rmd file contains code for the same.

3. Associated data files
   a) spearman correlations-20180913.RData: Gait features/AD status and demographic info.
   b) cogscores.RData: Cognitive scores information.
   c) prenormlmomallfeat.RData: Extracted L-moments
      for all gait features, prenormailized and scaled
      for JIVE.

